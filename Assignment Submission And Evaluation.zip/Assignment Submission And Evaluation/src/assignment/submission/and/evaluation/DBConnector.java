/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author saravana
 */
/*
 for insertion of records of large attributes I went for prepared statements
 for storing blob datatypes I have used prepared statement
*/
package assignment.submission.and.evaluation;
import java.sql.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileNotFoundException;
import static java.lang.System.*;
public class DBConnector {
 private Connection connection;
 private Statement statement;
 private String databaseName;
 private String userId;
 private String password;
 public DBConnector ( String DBName , String id , String password ) {
     databaseName = DBName;
     userId = id;
     this.password = password;
     try {
      String connectionString = "jdbc:mysql://localhost:3306/"+databaseName;
      Class.forName ( "com.mysql.cj.jdbc.Driver" );
      connection = DriverManager.getConnection ( connectionString , userId , this.password );
      statement  = connection.createStatement ( );
     }
     catch ( SQLException sqle ){
        out.println ( "Class not found check jar file existence: "+sqle );
     }
     catch ( ClassNotFoundException cnf ) {
         out.println ( "Class not found check jar file existence "+cnf );
     }
 }
 public boolean newFaculty ( Faculty f  ) throws SQLException {
     String insertQuery = "insert into Staff values ( '"+f.getId ( ) +"','"+f.getName ( )+"','"+f.getEmailId ( )+"')";
     return statement.executeUpdate ( insertQuery ) != 0; 
 }
 public boolean verifyFacultyIntegrity ( String fId , String password ) throws SQLException {
     String selectQuery = "select * from FacultyAuthentication where id = '" + fId + "' and password = '" + password + "' ";
     return statement.executeQuery ( selectQuery ).next ( );
 }
 public boolean verifyStudentIntegrity ( String sId , String password ) throws SQLException {
     String selectQuery = "select * from StudentAuthentication where id = '" + sId + "' and password = '" + password + "'";
     return statement.executeQuery ( selectQuery ).next ( );
 }
 public  Faculty getFaculty ( String fId ) throws SQLException { 
     String selectQuery = "select * from Staff where StaffId = '" + fId +"'";
     ResultSet rs = statement.executeQuery ( selectQuery );
     return rs.next ( ) ? new Faculty ( fId , rs.getString ( "staffId" ) , rs.getString ( "emailId" ) ) : null;
 }
 public Student getStudent ( String studentId ) throws SQLException {
     String selectQuery  = "select * from Student where StudId = '" + studentId + "'";
     ResultSet rs = statement.executeQuery ( selectQuery );
     return rs.next ( ) ? new Student ( studentId , rs.getString ( "studId" ) , rs.getString ( "emailId" ) ) : null;
 }
public ClassRoom getClassRoom ( String classRoomId ) throws SQLException {
    String selectQuery = "select * from ClassRoom where classId = '" + classRoomId + "'";
    ResultSet rs = statement.executeQuery ( selectQuery );
    if ( ! rs.next ( ) )
        return null;
    ClassRoom classRoom = new ClassRoom ( );
    classRoom.setId ( classRoomId );
    classRoom.setHandlingFacultyId ( rs.getString ( "handlingFaculty" ) );
    classRoom.setStudentsCount ( rs.getInt ( "noOfStudents" ) );
    classRoom.setSubjectName ( rs.getString ( "subjectName" ) );
    selectQuery = "select * from Student where studId in ( select studId from StudentClassRoom where classId = '" + classRoomId + "')";
    rs = statement.executeQuery ( selectQuery );
    int index = 0;
    rs.last ();
    Student students [] =  new Student [ rs.getRow ( ) ];
    rs.first ( );
    do {
        students [ index ++ ] = new Student ( rs.getString ( "studId" ) , rs.getString ( "studName" ) , rs.getString ( "emailId" ) );
    } while( rs.next ( ) );
    classRoom.setStudents ( students );
    return classRoom;
}
public boolean isThereClass ( String classId ) throws SQLException  {
    return statement.executeQuery ( "select classId from ClassRoom where classId = '" + classId + "'" ).next ( );
}
public void newAssignment ( AssignmentQuestion question ) throws SQLException , IOException {
    PreparedStatement pmt = connection.prepareStatement ( "insert into AssignmentQuestion values ( ? , ? , ? , ? , ? , ? , ? ) " );
    pmt.setString ( 1 , question.getId ( ) );
    pmt.setString ( 2 , question.getHeading ( ) );
    FileReader fr = new FileReader ( question.getDescription ( ) );
    pmt.setCharacterStream ( 3 , fr , ( int ) question.getDescription( ).length () );
    pmt.setString ( 4 , question.getFacultyId ( ) );
    pmt.setString ( 5 , question.getClassId ( ) );
    pmt.setDate ( 6 , question.getDeadline ( ) );
    pmt.setDate ( 7 , question.getAnnouncementDate ( ) );
    pmt.executeUpdate ( );
    fr.close ( );
}
public void storeSubmission ( Submission submission ) throws SQLException , FileNotFoundException {
   PreparedStatement pmt = connection.prepareStatement ( "insert into submission values ( ? , ? , ? , ? , ? , ? ) " );
   pmt.setString ( 1 , submission.getId ( ) );
   pmt.setString ( 3 , submission.getStudentId ( ) );
   pmt.setString ( 4 , submission.getAssignmentId ( ) );
   pmt.setDate ( 5 , submission.getSubmittedDate ( ) );
   pmt.setString ( 6 , submission.getClassId ( ) );
   pmt.setCharacterStream ( 2 , new FileReader ( submission.getContent ( ) ) , ( int ) submission.getContent ( ).length ( ) );
   pmt.executeUpdate ( );
}
public AssignmentQuestion [] postedAssignments ( String id , String requestor , String path ) throws SQLException , IOException {
    String selectQuery = requestor.equals ( "faculty" ) ? "select * from AssignmentQuestion where facultyId = '" + id + "'" : "select * from AssignmentQuestion where classId in ( select classId from StudentClassRoom where studId = '" + id + "' )";
    ResultSet rs = statement.executeQuery ( selectQuery );
    if ( ! rs.next ( ) )
        return null;
    rs.last ( );
    AssignmentQuestion [] questions = new AssignmentQuestion [ rs.getRow ( ) ];
    rs.first ( );
    int index = 0;
    FileOutputStream fos;
    do {
        Blob content = rs.getBlob ( "description" );
        byte  fileContents [ ] = content.getBytes ( ( long ) 1 , ( int ) content.length ( ) );
        fos = new FileOutputStream ( path + "\\Assignment" + ( index + 1 ) + ".txt" );
        fos.write ( fileContents );
        questions [ index ++ ] = new AssignmentQuestion ( rs.getString ( "assignmentId" ) , rs.getString ( "heading" ) , null , rs.getString ( "facultyId" ) , rs.getString ( "classId" ) , rs.getDate ( "postedDate" ) , rs.getDate ( "deadline" ) );   
    } while ( rs.next ( ) );
    fos.close ( );
    return questions;
}
public void newClassRoom ( ClassRoom classRoom ) throws SQLException {
     PreparedStatement pmt = connection.prepareStatement ( "insert into ClassRoom values ( ? , ? , ? , ? )" );
     String classId = classRoom.getId ( );
     pmt.setString ( 1 , classId );
     pmt.setString ( 2 , classRoom.getHandlingFacultyId ( ) );
     pmt.setInt ( 3 , classRoom.getStudentsCount ( ) );
     pmt.setString ( 4 , classRoom.getSubjectName ( ) );
     pmt.executeUpdate (  );
     Student [] students = classRoom.getStudents ( );
     String insertQueries = "insert into StudentClassRoom values ('" + students [ 0 ].getId ( ) + "','" + classId + "')";
     for ( int i = 1; i < students.length; i ++ ) {
        insertQueries  += ",('" + students [ i ].getId ( ) + "','" + classId + "')";
     }
     statement.executeUpdate ( insertQueries ); 
 }
 public Submission [] retrieveSubmissions ( String id , String requestor , String path ) throws IOException , SQLException {
     String selectQuery = requestor.equals ( "student" )? "select s.studentId , s.content , s.submissionId , s.classId , c.handlingFaculty , s.assignmentId , s.submittedDate from submission s inner join classroom c where s.classId = c.classId and s.studentId ='" + id + "'" : "select * from submission where assignmentId in ( select assignmentId from assignmentQuestion where facultyId = '" + id + "' )";
     ResultSet rs ;
     rs =  statement.executeQuery ( selectQuery ); 
     if ( ! rs.next ( ) )
         return null;
     rs.last ( );
     out.println ( "iam not responisble" );
     Submission [ ] submissions = new Submission [ rs.getRow ( ) ];
     rs.first ( );
     FileOutputStream fos;
     
     int index = 0;
     do {
        submissions [ index ++ ] = new Submission ( rs.getString ( "submissionId" ) , null , rs.getString ( "classId" ) , requestor.equals ( "student" ) ? rs.getString ( "handlingFaculty" ) : id , rs.getString ( "studentId" ) , rs.getString ( "assignmentId" ) );
        fos = new FileOutputStream ( path + "\\Answer" + ( index - 1 ) +".txt" );
        Blob blob = rs.getBlob ( "content" );
        byte [] content =blob.getBytes ( ( long ) 1 , ( int ) blob.length ( ) );
        fos.write ( content );
     } while ( rs.next ( ) );
     return submissions;
 }
 public String retrieveFacultyId ( String classId ) throws SQLException  {
     PreparedStatement pmt = connection.prepareStatement ( "select handlingFaculty from ClassRoom where classId = ?" );
     pmt.setString ( 1 , classId );
     ResultSet rs = pmt.executeQuery ( );
     return rs.getString ( "handlingFaculty" );
 }
}

