/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignment.submission.and.evaluation;
/**
 * @author saravana
 */
import java.util.Scanner;
import java.util.Calendar;
import java.util.regex.Pattern;
import java.sql.*;
import static java.lang.System.*;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.AudioInputStream;
//import java.io.File;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.io.File;
public class AssignmentSubmissionAndEvaluation {

    /**
     * @param args the command line arguments
     */
    static DBConnector db;
//    public static void main ( String ... args  ) {
//        db = new DBConnector ( "AssignmentsSystem" , "root" , "" );
//        db.retrieveSubmissions ( "19bcs166" , "faculty" , "E:\\" );
//    }
    public static void main(String[] args) {
        // TODO code application logic here
        db = new DBConnector ( "AssignmentsSystem" , "root" , "" );
        Scanner console = new Scanner ( System.in );
        String userId , password;
        boolean authenticationStatus = false;
        while ( true ) {
           out.println ( "MENU" );
           out.print ( "1.Faculty\n\n2.Student\n\n3.Exit\n\nEnter your choice: " );
           int choice = console.nextInt ( );
           String user = choice == 1 ? "Faculty" : "Student";
           out.println ( "\nSystem wants to verify whether your are a " + user + " of this instituition!\n" );
           int attemptCount = 0;
           if ( choice == 3 )
               exit ( 0 );
           while ( true ) {
             out.print ( "your ID: " );
             userId = console.next ( );
             out.print ( "your password: " );
             console.nextLine ( );
             password = console.nextLine ( );
             try {
                 if ( choice == 1 )
                     authenticationStatus = db.verifyFacultyIntegrity ( userId , password );
                 else if ( choice == 2 ) 
                     authenticationStatus = db.verifyStudentIntegrity ( userId , password );
             }
             catch ( SQLException sqe ) {
                 out.println ( "\nerror message: " + sqe + "\n\nSystem terminating upnormally!" );
                 exit ( - 1 );
             }
             if ( authenticationStatus ) {
                 authenticationStatus = false;
                 try {
                      AssignmentSubmissionAndEvaluation.alertAuthenticationSucess ( );
                 } 
                 catch ( LineUnavailableException | IOException | UnsupportedAudioFileException | InterruptedException  liui  ) {
                      out.println ( "system error ( for developer purpose only! )" + liui ); 
                 }
                   break;
             }
             try {
                 if ( attemptCount > 3 ) {
                     informMaximumLimitReached ( );
                     exit ( 0 );
                 }
                 AssignmentSubmissionAndEvaluation.alertAuthenticationFailure ( );
                 attemptCount += 1;
             } 
             catch ( LineUnavailableException | IOException | UnsupportedAudioFileException | InterruptedException  liui ) {
                 out.println ( "system error ( for developer purpose only! )" + liui ); 
                 exit ( -1 );
             }
             out.println ( );
           }
           if ( choice == 1 )
               AssignmentSubmissionAndEvaluation.facultyModule ( userId );
           else
              AssignmentSubmissionAndEvaluation.studentModule ( userId );
        }
  }
  static void facultyModule ( String facultyId ){
     Faculty faculty = null;
     try{ 
       faculty = db.getFaculty ( facultyId );
     }
     catch ( SQLException sqe ) {
       out.println ( "\nerror message: " + sqe + "\n\nSystem terminating upnormally!" );
       exit ( - 1 );  
     }
     while ( true ) { 
       out.print ( "\nMENU\n\n1.Create ClassRoom\n\n2.Post Assignment\n\n3.View Posted Assignments\n\n4.View Submitted Assignments\n\n5.Back\n\nEnter your choice: " );
       Scanner console = new Scanner ( System.in );
       int choice = console.nextInt ( );
         switch (choice) {
             case 1 -> {
                 out.print ( "\nNumber of students in your class: " );
                 int numberOfStudents = console.nextInt ( );
                 int counter  = numberOfStudents;
                 Student [] students = new Student [ numberOfStudents ];
                 String studentId;
                 out.print ( "\nGive Unique id for classroom: " );
                 String classRoomId = console.next ( );
                 try{ 
                  while ( db.isThereClass ( classRoomId )  ) {
                     out.print ( "\nThere already exists a classroom with this id!\n\nTry with a new one: " );
                     classRoomId = console.next ( );
                  }
                 }
                 catch ( SQLException sqe ) {
                     out.println ( "\"system error ( for developer purpose only! )" + sqe );
                 }
                 out.print ( "\nSubject name: " );
                 console.nextLine ( );
                 String subjectName = console.nextLine  ( );
                 out.println ( "\nIt is good to mail students to notify them that they got a new class!" );
                 out.println ( "\nBe cautious about the details you give! confirm manually whether the student belongs to your instituition!" );
                 while ( counter -- > 0 ) {
                     out.print ( "\nEnter student id of student " +  ( numberOfStudents - counter  )  + ": " );
                     studentId =  console.next ( );
                     try {
                         while ( ( students [ numberOfStudents - counter  - 1 ] = db.getStudent ( studentId ) ) == null ) {
                             out.print ( "\nThe exists no student with this id!\n\nEnter student id of student " +  ( numberOfStudents - counter )  + ": " );
                             studentId = console.next ( );
                         }
                     }
                     catch ( SQLException sqe ){
                         out.println ( "\nsystem error ( for developer purpose only! )" + sqe );
                         exit ( - 1 );
                     }
                 }   
                 faculty.registerClassRoom ( new ClassRoom ( classRoomId , facultyId , numberOfStudents , students , subjectName ) );
                 out.print ( "\nClassroom registration successful!" );  
             }
             case 2 -> {
                 out.print ( "\nGive unique id for assignment: " );
                 String id = console.next ( );
                 out.print ( "\nHeading of the assignment: " );
                 console.nextLine ( );
                 String heading = console.nextLine ( );
                 out.print ( "\nPath of the Assignment Question file: " );
                 String path = console.next (  );
                 while ( ! verifyPath ( path ) ) {
                     out.println ( "\nEither path not exists or wrong path format!" );
                     out.print ( "\nTry again ( path of assignment question file ): " );
                     path = console.next ( );
                 }
                 out.print ( "\nDeadline Date ( format: yyyy-mm-dd ): " );
                 String date = console.next ( );
                 while ( ! AssignmentSubmissionAndEvaluation.verifyDate ( date ) ) {
                     out.println ( "\nDate is format sensitive and cannot be today or past!" );
                     out.print ( "\nEnter again: " );
                     date = console.next ( );
                 }
                 out.print ( "\nThe id of the class to post there: " );
                 String classId = console.next ( );
                 faculty.postAssignment ( new AssignmentQuestion ( id , heading , new File ( path ) , faculty.getId ( ) , classId , new Date ( Calendar.getInstance ( ).getTimeInMillis ( ) ) , Date.valueOf ( date ) ) );
                 out.print ( "\nAssignment posted successfully!" );
             }
             case 3 -> {
                 out.print ( "\nTell me one path, I will make the assignment questions available there: " );
                 String path = console.next ( );
                 while ( ! verifyPath ( path ) ) {
                     out.println ( "\nEither path not exists or wrong path format!" );
                     out.print ( "\nTry again: " );
                     path = console.next ( );
                 }
                 out.println ( "\nDetails of the assignment you have given so far is below!\n\nContents of the question is available in the path -> " + path  );
                 AssignmentQuestion [ ] questions = faculty.viewPostedAssignments ( path );
                 if ( questions == null ) {
                     out.print ( "\nNo assignments posted by you till date!" );
                     continue;
                 }
                 for ( AssignmentQuestion question : questions ) {
                     question.display();
                 }
                 out.print ( "\nSee assignment question files in " + path );
             }
             case 4 -> {
                 out.print ( "\nGive a path to store your students' submissions: " );
                 String path = console.next ( );
                 while ( ! verifyPath ( path ) ) {
                          out.println ( "\nEither path not exists or wrong path format!" );
                          out.print ( "\nTry again : " );
                          path = console.next ( );
                 }       
                 Submission [] submissions =  faculty.viewSubmissions ( path );
                 if ( submissions == null ) {
                          out.println ( "\nNo submissions found! till date.." );
                          continue;
                 }       
                 out.println ( "\nBelow the details of your submissions!" );
                 for ( Submission submission : submissions )
                          submission.display ( );
                 out.println ( "\nsee " + path + " for submission files!" );
             }
             case 5 -> {
                 return;
             }
             default -> {
             }
         }
     }
  }
  static void studentModule ( String studentId ) {
      Scanner console = new Scanner ( System.in );
      Student student = null;
      try {
       student = db.getStudent ( studentId );
      }
      catch ( SQLException sqe ) {
          out.println ( "System error: + " + sqe + "! terminating upnormally!" );
          exit ( - 1 );
      }
      int choice;
      while ( true ) {
          out.print ( "\nMenu\n\n1.View Assignment Questions\n\n2.Submit Assignment\n\n3.View your Submissions\n\n4.Exit\n\nEnter your choice: " );
          choice = console.nextInt ( );
          switch (choice) {
              case 1 ->                   {
                      out.print ( "\nEnter the path to save the questions there: " );
                      String path = console.next ( );
                      while ( ! verifyPath ( path ) ) {
                          out.println ( "\nEither path not exists or wrong path format!" );
                          out.print ( "\nTry again : " );
                          path = console.next ( );
                      }       AssignmentQuestion [] questions = student.viewAssignmentQuestions ( path );
                      if ( questions == null ) {
                          out.print ( "\noh my goodness you didn't get any assignments!" );
                          continue;
                      }       for ( AssignmentQuestion question : questions ) {
                          question.display ( );
                      }       out.print ( "\n\nSee " + path + "for the questions!" );
                  }
              case 2 ->                   {
                      out.println ( "\nyou may be subjected to lot of assignments.. kindly particulate the following details! " );
                      out.print ( "\nclass Id: " );
                      String classId = console.next ( );
                      out.print ( "\nAssignment Id: " );
                      String assignmentId  = console.next ( );
                      out.print ( "\nPath where the assignment answer resides: " );
                      String path = console.next ( );
                      while ( ! verifyPath ( path ) ) {
                          out.println ( "\nEither path not exists or wrong path fomat!" );
                          out.print ( "\nTry again : " );
                          path = console.next ( );
                      }       out.print ( "\nFinally give unique id for your submission: " );
                      String submissionId = console.next ( );
                      student.submitAssignmentAnswer ( new Submission ( submissionId , new File ( path ) , classId , null , studentId , assignmentId ) );
                      out.println ( "\nAnswer submitted sucessfully!" );
                  }
              case 3 ->                   {
                      out.print ( "\nGive a path to store your submissions: " );
                      String path = console.next ( );
                      while ( ! verifyPath ( path ) ) {
                          out.println ( "\nEither path not exists or wrong path format!" );
                          out.print ( "\nTry again : " );
                          path = console.next ( );
                      }       Submission [] submissions =  student.viewSubmissions ( path );
                      if ( submissions == null ) {
                          out.println ( "\nNo submissions found! till this date.." );
                          continue;
                      }       out.println ( "\nBelow the details of your submissions!" );
                      for ( Submission submission : submissions )
                          submission.display ( );
                      out.println ( "\nsee " + path + " for submission files!" );
                  }
              case 4 -> {
                  return;
              }
              default -> out.println ( "\nInvalid choice!" );
          }
      }
  }
  static boolean verifyDate ( String date ) {
      if ( Pattern.matches("(((20[012]\\d|19\\d\\d)|(1\\d|2[0123]))-((0[0-9])|(1[012]))-((0[1-9])|([12][0-9])|(3[01])))" , date ) ) {
          if ( new java.util.Date ( Date.valueOf ( date ).getTime ( ) ) .after ( Calendar.getInstance ( ).getTime ( ) ) ) {
              return true;
          }
      }
      return false;
  }
  static boolean verifyPath ( String path ){
      Path pathObj;
      try {
          pathObj = Paths.get ( path );
      }
      catch ( InvalidPathException ipe ) {
          return false;
      }
      return Files.exists ( pathObj );
  }
  static void alertAuthenticationSucess (  ) throws UnsupportedAudioFileException , IOException , LineUnavailableException , InterruptedException {
      Clip successAlert;
      AudioInputStream successAudio;
      successAlert = AudioSystem.getClip ( );
      successAudio = AudioSystem.getAudioInputStream ( new File ( "./src/Content/success...wav" ).getAbsoluteFile ( ) );
      successAlert.open ( successAudio ); 
      successAlert.start ( );
      Thread.sleep ( 2500 );
  }
  static void alertAuthenticationFailure ( ) throws UnsupportedAudioFileException , IOException , LineUnavailableException , InterruptedException {
      Clip failureAlert;
      AudioInputStream failureAudio;
      failureAlert = AudioSystem.getClip ( );
      failureAudio = AudioSystem.getAudioInputStream ( new File ( "./src/Content/failed.wav" ).getAbsoluteFile ( ) );
      failureAlert.open ( failureAudio );
      failureAlert.start ( );
      Thread.sleep ( 3000 );
  }
  static void informMaximumLimitReached ( ) throws UnsupportedAudioFileException , IOException , LineUnavailableException , InterruptedException{
      Clip failureAlert; 
      AudioInputStream failureAudio;
      failureAlert = AudioSystem.getClip ( );
      failureAudio = AudioSystem.getAudioInputStream ( new File ( "./src/Content/maximum.wav" ).getAbsoluteFile ( ) );
      failureAlert.open ( failureAudio );
      failureAlert.start ( );
      Thread.sleep ( 3000 );     
  }
}
