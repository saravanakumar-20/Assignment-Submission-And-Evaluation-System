/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment.submission.and.evaluation;
import static assignment.submission.and.evaluation.AssignmentSubmissionAndEvaluation.db;
import static java.lang.System.out;
import java.io.IOException;
import java.sql.*;
/**
 *
 * @author saravana
 */
public class Faculty {
    private String id;
    private String facultyName;
    private String email;
    public Faculty ( String id , String name , String email ){
        this.id = id;
        this.facultyName = name;
        this.email = email;
    }
    public Faculty ( ) {
        
    }
    public String getName ( ) {
        return facultyName;
    }
    public String getId ( ) {
        return this.id;
    }
    public String getEmailId ( ) {
        return email;
    }
    public void setName ( String name ) {
       facultyName = name; 
    }
    public void setId ( String id ) {
        this.id = id;
    }
    public void setEmailId ( String email ) {
        this.email = email;
    }
    public void registerClassRoom ( ClassRoom classRoom ) {
      try {
           db.newClassRoom ( classRoom );
           out.println ( "\nClassroom registered succcessfully!" );
         }
         catch ( SQLException sqe ) {
           out.println ( "\"system error ( for developer purpose only! )" + sqe );
           System.exit ( -1 );
         }
   }
    public void postAssignment ( AssignmentQuestion question ) {
        try {
            db.newAssignment ( question );
        }
        catch ( SQLException | IOException si ) {
           out.println ( "\"system error ( for developer purpose only! )" + si );
           System.exit ( -1 ); 
        } 
    }
    public AssignmentQuestion [] viewPostedAssignments ( String path ) {
        try {
          return db.postedAssignments ( this.id , "faculty" , path ); 
        }
        catch ( SQLException | IOException si ) {
           out.println ( "\"system error ( for developer purpose only! )" + si );
           System.exit ( -1 );
        }
        return null;
    }
    public Submission [] viewSubmissions ( String path ) {
      try {
          return db.retrieveSubmissions ( this.id , "faculty" , path );
      }
      catch ( IOException | SQLException is ) {
          System.out.println ( "\nSystem error: " + is + "! system terminating upnormally!" );
          System.exit ( - 1 );
      }
      return null;
   }
}
