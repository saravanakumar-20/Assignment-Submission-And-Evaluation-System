/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment.submission.and.evaluation;
import java.io.File;
import java.sql.*;
/**
 *
 * @author saravana
 */
public class Submission {
   String id;
   File content;
   String studentId;
   String assignmentId;
   String classId;
   Date submittedDate;
   String facultyId;
   public Submission ( ) {
      
   }
   public Submission ( String id , File content , String classId , String facultyId , String studentId , String assignmentId ) {
       this.id = id;
       this.content = content;
       this.studentId = studentId;
       this.assignmentId = assignmentId;
       this.classId = classId;
   }
   public String getId ( ) {
       return this.id;
   }
   public File getContent ( ) {
       return this.content;
   }
   public String getStudentId ( ) {
       return this.studentId;
   }
   public String getAssignmentId ( ) {
       return this.assignmentId;
   }
   public String getClassId ( ) {
       return this.classId;
   }
   public Date getSubmittedDate ( ) {
       return this.submittedDate;
   }
   public void setId ( String id ) {
       this.id = id;
   }
   public void setSubmittedDate ( Date date ) {
       this.submittedDate = date;
   }
   public void setStudentId ( String id ) {
       this.studentId = id;
   }
   public void setClassId ( String id ) {
       this.classId = id;
   }
   public void setContent ( File content ) {
       this.content = content;
   }

   public void display() {
       System.out.print ( "\n\nSubmission Id: " + this.id + "\nclass Id: " + this.classId + "\nFaculty Id: " + this.facultyId + "\nStudent Id: " + this.studentId + "\nAssignment Id: " + this.assignmentId );  
    }
}
