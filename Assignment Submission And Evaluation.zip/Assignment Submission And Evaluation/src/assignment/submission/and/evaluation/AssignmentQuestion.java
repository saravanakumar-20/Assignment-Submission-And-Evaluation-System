/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment.submission.and.evaluation;
import java.sql.*;
import java.io.File;
import static java.lang.System.*;
/**
 *
 * @author saravana
 */
public class AssignmentQuestion {
   private String id;
   private String heading;
   private File description;
   private String facultyId;
   private String classId;
   private Date dateOfAnnouncement;
   private Date deadline;
   public AssignmentQuestion ( String id , String heading , File desc , String fId , String classId , Date announcement , Date deadline ) {
       this.id = id;
       this.heading = heading;
       this.description = desc;
       this.facultyId = fId;
       this.classId = classId;
       this.dateOfAnnouncement = announcement;
       this.deadline = deadline;
   }
   public void display ( ) {
      out.print ( "\n\nId: " + this.id + "\nHeading: " + this.heading + "\nPosted by(Faculty Id): " + this.facultyId + "\nclassId: " + this.classId + "\nDate of announcement: " + this.dateOfAnnouncement + "\nDeadline for submission: " + this.deadline );
   }
   public String getId ( ) {
       return this.id;
   }
   public String getHeading ( ) {
       return this.heading;
   }
   public String getFacultyId ( ) {
       return this.facultyId;
   }
   public String getClassId ( ) {
       return this.classId;
   }
   public void setClassId ( String id ) {
       this.classId = id;
   }
   public void setId ( String id ) {
       this.id = id;
   }
   public void setFacultyId ( String id ) {
       this.facultyId = id;
   }
   public void setHeading ( String heading ) {
       this.heading = heading;
   }
   public void setAnnouncementDate ( Date date ) {
       this.dateOfAnnouncement = date;
   }
   public Date getAnnouncementDate ( ) {
       return this.dateOfAnnouncement;
   }
   public void setDeadline ( Date date ) {
       this.deadline = date; 
   }
   public Date getDeadline ( ) {
       return this.deadline;
   }
   public File getDescription ( ) {
       return this.description;
   }
   public void setDescription ( File desc ) {
       this.description = desc;
   }
}
