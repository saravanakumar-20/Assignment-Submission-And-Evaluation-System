/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment.submission.and.evaluation;

/**
 *
 * @author saravana
 */
public class ClassRoom {
   String classId;
   String handlingFacultyId;
   int studentsCount;
   Student [] students;
   String subjectName;
   public ClassRoom ( String id , String fId , int strength , Student [] students , String subject ) {
     this.classId = id;
     this.handlingFacultyId = fId;
     this.studentsCount = strength;
     this.students = new Student [ strength ];
     System.arraycopy ( students , 0 , this.students , 0 , students.length ); //deep copy
     this.subjectName = subject;
   }
   public ClassRoom ( ) {
       
   }
   public int getStudentsCount ( ) {
       return this.studentsCount;
   }
   public void setStudentsCount ( int strength ) {
       this.studentsCount = strength;
   }
   public String getHandlingFacultyId ( ) {
       return this.handlingFacultyId;
   }
   public void setHandlingFacultyId ( String id ) {
       this.handlingFacultyId = id;
   }
   public String getId ( ) {
       return this.classId;
   }
   public void setId ( String id ) {
       this.classId = id;
   }
   public Student [] getStudents ( ) {
       return this.students;
   }
   public void setStudents ( Student [] students ) {
       System.arraycopy ( students , 0 , this.students , 0 , students.length );
   }
   public String getSubjectName ( ) {
       return this.subjectName;
   }
   public void setSubjectName ( String subject ) {
       this.subjectName = subject;
   }
}
