/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment.submission.and.evaluation;
import static assignment.submission.and.evaluation.AssignmentSubmissionAndEvaluation.db;
import java.util.Calendar;
import java.io.IOException;
import java.sql.*;
/**
 *
 * @author saravana
 */
public class Student {
   private String studentId;
   private String emailId;
   private String studentName;
   public Student ( String id , String name , String mail  ) {
      this.studentId = id;
      this.emailId = mail;
      this.studentName = name;
   }
   public Student (  ) {
       
   }
   public void setName ( String name ) {
     this.studentName = name;  
   }
   public void setEmailId ( String mail ) {  
     this.emailId = mail; 
   }
   public void setId ( String id ) {
      this.studentId = id; 
   }
   public String getId ( ) {
      return this.studentId;
   }
   public String getMailId ( ) {
      return this.emailId;
   }
   public String getName ( ) {
      return this.studentName;
   }
   public AssignmentQuestion [] viewAssignmentQuestions ( String path ) {
       try {
           return db.postedAssignments ( this.studentId , "student" , path );
       }
       catch ( SQLException | IOException si ) {
           System.out.println ( "\nSystem error: " + si + "! system terminating upnormally!" );
           System.exit ( - 1 );
       }
       return null;
   }
   public void submitAssignmentAnswer ( Submission submission ) {
       submission.setSubmittedDate ( new Date ( Calendar.getInstance ( ).getTimeInMillis ( ) ) );
       try {
           db.storeSubmission ( submission );
       }
       catch ( SQLException | IOException si ) {
           System.out.println ( "\nSystem error: " + si + "! system terminating upnormally!" );
           System.exit ( - 1 );
       }
   }
   public Submission [] viewSubmissions ( String path ) {
      try {
          return db.retrieveSubmissions ( this.studentId , "student" , path );
      }
      catch ( IOException | SQLException is ) {
          System.out.println ( "\nSystem error: " + is + "! system terminating upnormally!" );
          System.exit ( - 1 );
      }
      return null;
   }
}
